# Todo

* [ ] Make layout with trending aside tag

* [ ] Don't allow spaces in username

* [ ] Post Model
    * [ ] Make non-static model

* [ ] Mentions
    * [ ] Mentions table
    * [ ] Replace @username with  @[id] on backend
    * [ ] Replace @[id] with <a href="link_to_user"\>@username</a\>
    