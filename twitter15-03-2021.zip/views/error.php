<?php

/** @var string $error */

?>


<h1><?= $error ?></h1>