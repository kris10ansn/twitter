<?php


namespace app\models;

use app\src\Database;

/**
 * Class UserModel
 * @package app\models
 */
class UserModel
{
    public const SORT_FOLLOWERS = "(SELECT COUNT(*) FROM follow WHERE followed_id=user.id)";

    public int $id;
    public string $username;
    public string $firstname;
    public string $lastname;
    public string $email;
    public string $created_at;
    public string $password;
    public string $biography;
    public ?int $favorite_user;

    private ?int $followerCount = null;
    private ?int $followsCount = null;

    public array $fields = [ "username", "firstname", "lastname", "email", "password", "biography", "favorite_user" ];


    public function sync(): bool
    {
        $db = Database::getInstance();
        $fields = implode(",", array_map(fn($f) => "$f=:$f", $this->fields));

        $statement = $db->prepare("
            UPDATE user
            SET $fields
            WHERE user.id=:id
        ");

        foreach ($this->fields as $fieldName) {
            $statement->bindValue(":$fieldName", $this->{$fieldName});
        }

        $statement->bindValue(":id", $this->id);

        return $statement->execute();
    }

    public function follow(int $followId): bool
    {
        $db = Database::getInstance();

        $statement = $db->prepare("INSERT INTO follow (follower_id, followed_id) VALUES (:id, :follow_id)");

        $statement->bindValue(":id", $this->id);
        $statement->bindValue(":follow_id", $followId);

        return $statement->execute();
    }

    public function unfollow(int $followedId): bool
    {
        $db = Database::getInstance();

        $statement = $db->prepare("DELETE FROM follow WHERE follower_id=:id AND followed_id=:followed_id");

        $statement->bindValue(":id", $this->id);
        $statement->bindValue(":followed_id", $followedId);

        return $statement->execute();
    }

    public function follows(int $userId): bool
    {
        $db = Database::getInstance();

        $statement = $db->prepare("SELECT * FROM follow WHERE follower_id=:id AND followed_id=:user_id");

        $statement->bindValue(":id", $this->id);
        $statement->bindValue(":user_id", $userId);

        $statement->execute();

        if ($statement->fetch(\PDO::FETCH_ASSOC)) {
            return true;
        }

        return false;
    }

    public function followerCount(): int
    {
        if ($this->followerCount !== null) {
            return $this->followerCount;
        }

        $db = Database::getInstance();

        $statement = $db->prepare("SELECT COUNT(*) FROM follow WHERE followed_id=:user_id");
        $statement->execute([":user_id" => $this->id]);

        $this->followerCount = (int) $statement->fetchColumn();

        return $this->followerCount;
    }

    public function followers($sort = "user.created_at", $order = "DESC"): array
    {
        $db = Database::getInstance();

        $statement = $db->prepare("
            SELECT * FROM follow
                JOIN user ON follower_id=user.id
            WHERE followed_id=:id
            ORDER BY $sort $order
        ");
        $statement->execute([":id" => $this->id]);

        return $statement->fetchAll(\PDO::FETCH_CLASS, self::class);
    }

    public function following($sort = "user.created_at", $order = "DESC"): array
    {
        $db = Database::getInstance();

        $statement = $db->prepare("
            SELECT * FROM follow 
                JOIN user 
                    ON follow.followed_id=user.id
            WHERE follower_id=:id
            ORDER BY $sort $order
        ");

        $statement->execute([":id" => $this->id]);

        return $statement->fetchAll(\PDO::FETCH_CLASS, self::class);
    }

    public function followsCount(): int
    {
        if ($this->followsCount !== null) {
            return $this->followsCount;
        }

        $db = Database::getInstance();

        $statement = $db->prepare("SELECT COUNT(*) FROM follow WHERE follower_id=:user_id");
        $statement->execute([":user_id" => $this->id]);

        $this->followsCount = (int) $statement->fetchColumn();
        return $this->followsCount;
    }

    public static function from(int $id): ?UserModel
    {
        $db = Database::getInstance();

        $statement = $db->prepare("SELECT * FROM user WHERE id=:id");
        $statement->execute([":id" => $id]);

        $fetchedObject = $statement->fetchObject(UserModel::class);

        if ($fetchedObject) {
            return $fetchedObject;
        }

        return null;
    }

    /**
     * @param $where
     * @return UserModel|null
     */
    public static function find($where): ?UserModel
    {
        $tableName = "user";
        $selectors = implode("AND", array_map(fn($key) => "$key = :$key", array_keys($where)));
        $sql = "SELECT * FROM $tableName WHERE $selectors";

        $db = Database::getInstance();
        $statement = $db->prepare($sql);

        foreach ($where as $key => $value) {
            $statement->bindValue(":$key", $value);
        }

        $statement->execute();
        $fetchedObject = $statement->fetchObject(UserModel::class);

        if ($fetchedObject) {
            return $fetchedObject;
        }

        return null;
    }

    /**
     * @param string $sort
     * @param string $order
     * @return array
     */
    public static function all($sort="user.created_at", $order="ASC"): array
    {
        $db = Database::getInstance();
        $statement = $db->prepare("SELECT * FROM user ORDER BY $sort $order");
        $statement->execute();

        return $statement->fetchAll(\PDO::FETCH_CLASS, self::class);
    }
}